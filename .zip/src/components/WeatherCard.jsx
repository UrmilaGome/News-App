import React from "react";

const WeatherCard = () => {
  return (
    <div className=" card p-5 col-md-4 col-sm-12 rounded-0 shadow-sm">
      <h1 className="display-5">Indore</h1>
      <h1 className="display-6 text-secondary">24</h1>
      <img src="" alt="" />
    </div>
  );
};

export default WeatherCard;
